package com.example.mitchelljohnson.familymapproject;
import com.example.mitchelljohnson.familymapproject.RequestsAndResponses.register.*;
import com.example.mitchelljohnson.familymapproject.RequestsAndResponses.Login.*;
import com.example.mitchelljohnson.familymapproject.proxyServer;
import com.example.mitchelljohnson.familymapproject.RequestsAndResponses.person.*;
import com.example.mitchelljohnson.familymapproject.RequestsAndResponses.event.*;


import static org.junit.Assert.*;
import org.junit.* ;
import java.sql.*;

import java.util.ArrayList;
import java.util.Set;

public class proxyServerTest {

    registerRequest shouldWork;
    @Before
    public void setUp() throws Exception {
        //makes sure that the server is running when you test this.  Nothing we really need to do besides generate data on this side
        //public registerRequest(String first, String last, String user, String pass, String g, String mail)
        shouldWork = new registerRequest("Mitchell", "Johnson", "Mitchell96", "wafflePasta", "m", "email@gmail.com");




    }

    @After
    public void tearDown(){

    }
    //This test for some reason runs after login, so it's causing some serious shenanagins
    @Test
    public void testRegister(){

        registerRequest wontWork = new registerRequest("Larry", "TheCableGuy", "Mitchell96", "REEEEEEEEEE", "m", "kaufa");
        //the message value is only ever not null when the attempt fails.
        registerRequest bully =new registerRequest("bully", "boy", "bully", "bully", "f","bully");
        registerResponse r = proxyServer.Register("localhost", "8080", bully);
        assertNull(r.message);
        //the fail case:
        registerResponse wrong = proxyServer.Register("localhost", "8080", wontWork);
        assertNotNull(wrong.message);
    }

    @Test
    public void testLogin() throws InterruptedException {
        loginRequest regularRequest = new loginRequest("Mitchell96", "wafflePasta");
        loginRequest wrongRequest = new loginRequest("Mitchell96", "WHEEEEEEE");
        //Thread.sleep(3000);
        registerResponse r = proxyServer.Register("localhost", "8080", shouldWork);
        //Thread.sleep(3000);
        registerResponse loginResponse = proxyServer.Login("localhost", "8080", regularRequest);
        assertNull(loginResponse.message);
        //the fail case:
        registerResponse wrongResponse = proxyServer.Login("localhost", "8080", wrongRequest);
        assertNotNull(wrongResponse.message);
    }

    @Test
    public void testPeople() throws InterruptedException {
        loginRequest regularRequest = new loginRequest("Mitchell96", "wafflePasta");
        Thread.sleep(3000);
        registerResponse loginResponse = proxyServer.Login("127.0.0.1", "8080", regularRequest);
        personRequest toTest= new personRequest(loginResponse.personID, loginResponse.authToken);
        Thread.sleep(3000);
        personsResponse people = proxyServer.getPersons("127.0.0.1", "8080", toTest);
        boolean OGFound = false;
        for( personResponse person : people.data){
            if(!person.descendant.equals("Mitchell96")){
                assertFalse(true);
            }
            if(person.firstName.equals("Mitchell")){
                OGFound = true;
            }
        }
        if(!OGFound){
            assertFalse(true);
        }
    }
        //Ima be completely honest, for this one and testPerson, I have no idea how to create failing tests for these ones.
    @Test
    public void testEvents(){
        loginRequest regularRequest = new loginRequest("Mitchell96", "wafflePasta");
        registerResponse loginResponse = proxyServer.Login("127.0.0.1", "8080", regularRequest);
        personRequest toTest= new personRequest(loginResponse.personID, loginResponse.authToken);
        eventSet events = proxyServer.getEvents("127.0.0.1", "8080", toTest);
        boolean OGFound = false;
        for( event even : events.data){
            if(!even.descendant.equals("Mitchell96")){
                assertFalse(true);
            }
            if(even.personID.equals(loginResponse.personID)){
                OGFound = true;
            }
        }
        if(!OGFound){
            assertFalse(true);
        }
    }
}