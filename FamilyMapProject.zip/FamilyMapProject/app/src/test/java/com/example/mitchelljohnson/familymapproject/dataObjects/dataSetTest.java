package com.example.mitchelljohnson.familymapproject.dataObjects;

import com.example.mitchelljohnson.familymapproject.RequestsAndResponses.Login.loginRequest;
import com.example.mitchelljohnson.familymapproject.RequestsAndResponses.event.*;
import com.example.mitchelljohnson.familymapproject.RequestsAndResponses.person.personRequest;
import com.example.mitchelljohnson.familymapproject.RequestsAndResponses.person.*;
import com.example.mitchelljohnson.familymapproject.RequestsAndResponses.register.registerRequest;
import com.example.mitchelljohnson.familymapproject.RequestsAndResponses.register.registerResponse;
import com.example.mitchelljohnson.familymapproject.SearchActivity.SearchActivity;
import com.example.mitchelljohnson.familymapproject.dataObjects.dataSet;
import com.example.mitchelljohnson.familymapproject.dataObjects.*;
import com.example.mitchelljohnson.familymapproject.proxyServer;
import com.example.mitchelljohnson.familymapproject.SearchActivity.*;

import org.junit.*;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class dataSetTest {
    loginRequest regularRequest = new loginRequest("Mitchell96", "wafflePasta");
    dataSet toUse;
    model m = model.getInstance();
    //registerRequest shouldWork = new registerRequest("Mitchell", "Johnson", "Mitchell96", "wafflePasta", "m", "email@gmail.com");
    //loginRequest regularRequest = new loginRequest("Mitchell96", "wafflePasta");
       // proxyServer.Register("127.0.0.1", "8080", shouldWork);
    registerResponse loginResponse = proxyServer.Login("127.0.0.1", "8080", regularRequest);

    @Before
    public void setUp() throws Exception {
        //makes sure that the server is running when you test this.  Nothing we really need to do besides generate data on this side
        //public registerRequest(String first, String last, String user, String pass, String g, String mail)
        personRequest toTest= new personRequest(loginResponse.personID, loginResponse.authToken);
        personResponse singular = proxyServer.getPerson("127.0.0.1","8080", toTest);
        personsResponse people = proxyServer.getPersons("127.0.0.1", "8080", toTest);
        eventSet events = proxyServer.getEvents("127.0.0.1", "8080", toTest);
        toUse = new dataSet(events, people, singular);
        m.setData(toUse);
    }

    @After
    public void tearDown(){}

    @Test
    public void testGetOGPerson(){
        //should test to make sure each person is appropriately connected.
        person OG = toUse.getOGPerson();
        person mother = OG.mother;
        person father = mother.spouse;
        person shouldBeOG = father.child;
        assertEquals(OG.personID, shouldBeOG.personID);
        //we want to make sure that the personID's are not actually all the same, or that getting the spouse of the spouse doesn't result
        //in an entirely different person
        person grandmother = mother.mother.spouse.spouse;
        person grandma = mother.mother;
        //they should be pointing at the same place in memory
        assertEquals(grandma.personID, grandmother.personID);
        //finally, grandma's child is not the same as mom's child.  so we'll check that now to make sure no hankypanky is going
        //on in how the child is being referenced
        assertNotEquals(grandma.child.personID, mother.child.personID);


    }

    @Test
    public void testEventOrder(){
        //we're going to start by double checking the chronology of events in their lifeEvents
        //I store life events in a tree set and made events comparable by year, so this entire test is kinda joke, but whatevs.
        person OG = toUse.getOGPerson();
        person mother = OG.mother;
        ArrayList<event> events = mother.getLifeEvents();
        event old = null;
        for(event even : events){
            if(old == null){
                old = even;
            }
            else {
                //if the previous event year is greater than the current event, then the ordering is wrong.
                if(Integer.parseInt(old.getYear()) > Integer.parseInt(even.getYear())){
                    assertFalse(true);
                }
            }
        }
        person grandma = mother.mother;
        events = grandma.getLifeEvents();
        old = null;
        for(event even : events){
            if(old == null){
                old = even;
            }
            else {
                //if the previous event year is greater than the current event, then the ordering is wrong.
                if(Integer.parseInt(old.getYear()) > Integer.parseInt(even.getYear())){
                    assertFalse(true);
                }
            }
        }
    }

    /*
     * Lastly and most importantly, filtering is done in every class individually and does not alter person data in the model.
     * the model keeps a list of things that each activity should filter out when displaying results, which hopefully makes the pages more responsive
     * so we'll be dynamically checking the filter functions
     */

    @Test
    public void testEventFilters(){
        //first basic test, check to make sure banning events works appropriately
        m.addBannedEvent("birth");
        person OG = m.getUser();
        ArrayList<event> events = OG.getLifeEvents();
        ArrayList<event> newEvents = new ArrayList<>();
        for(event even : events ){
            if(!m.inBannedEventTypes(even)){
                newEvents.add(even);
            }
        }
        assertNotEquals(events.size(), newEvents.size());
        //test to see if the eventType is case Sensitive or case  Insensitive
        m.removeBannedEventType("birth");

        m.addBannedEvent("Birth");
        ArrayList<event> caseEvents = new ArrayList<>();
        for(event even : events ){
            if(!m.inBannedEventTypes(even)){
                caseEvents.add(even);
            }
        }
        assertEquals(events.size(), caseEvents.size());
        //because all the events dynamically generated will have been made lowercase, these two arraylists should not be equal.
        // while filter is case sensitive, what goes into banned event types is not. so all births will be marked as birth, and there will be now Birth types.
        assertNotEquals(caseEvents.size(), newEvents.size());
        /*events banned because of their person are a bit more tricky.
         *they require that I run the person checks on them vs just checking the banned event types.
         */
    }
    /*
    * I decided it would be smart to break up person filtering and event filtering because event filtering is already hecka long.
    * This is gonna be fairly straightforward because I just have bools storing what to do with them.
    * so what you see here isn't a perfect test, but it's really all we got.
    * */
    @Test
    public void testPersonFilters(){
        //this is a simple boolean put into an if statement.  Normally I wouldn't test this, but you explicitly said I have to.
        m.toggleFemale();
        //this is also a simple boolean in an if statement.  This isn't rocket science.
        m.setFatherSide(false);
        //in this test, we'll check for father, mother, grandmother on father's side, and grandfather on mother's side, of which, only the grandfather should be found
        ArrayList<person> thePeeps = new ArrayList<>();
        person OG = m.getUser();
        boolean foundGPa = false;
        person mother = OG.mother;
        person father = OG.father;
        person gMa = father.mother;
        person gPa = mother.father;
        //also because of how this is set up, everything ever must be done recursively.  enjoy this fun new not test function
        thePeeps = getHumans(OG, thePeeps);
        for(person perp : thePeeps) //get it?  perp for perpetrator.  I'm hilarious.  Also I've been watching too much b99
        {
            if(mother.personID.equals(perp.personID) || father.personID.equals(perp.personID)   //here's all the failing test cases
                    || gMa.personID.equals(perp.personID)){
                assertFalse(true);
            }
            else if(gPa.personID.equals(perp.personID)){    //here's the successful one
                foundGPa = true;
            }
        }
         //here's the one successful one
            assertTrue(foundGPa);
    }

    public ArrayList<person> getHumans(person p, ArrayList<person> allThePeeps){
       if(!m.isGenderBanned(p)) {
           allThePeeps.add(p);
       }

            if(m.isFatherSide() && p.father!=null){
                return getHumans(p.father, allThePeeps);
            }
            else if(!m.isFatherSide()){
                m.setFatherSide(true);
            }
            if(m.isMotherSide()&& p.mother != null){
                return getHumans(p.mother, allThePeeps);
            }
            else if(!m.isMotherSide()){
                m.setMotherSide(true);
            }
            return allThePeeps;
    }

    /*
    * you know, I didn't plan my code for any of these test cases.  every part of my search function is private in Search activity.
    * and it references its private member variables.  so there's no good way to access it.  you really enjoy making my life difficult,
    * don't you?
    * But I do have some searching capabilites that I can show off easily
    * */
    @Test
    public void testSearch() {
        //I suppose we'll start with a fun game of fetch, shall we?
        person OG = m.getUser();
        person random = OG.father.mother.spouse;
        String randomID = random.personID;
        event e = new event("WHEEEEE", "albus dumbledore", random.personID, "12", "13", "Canada", "alberta", "waffle", "420");
        random.addEvent(e);
        person fetched = m.findbyID(randomID);
        //this means they're pointing at the same person
        assertEquals(fetched.personID, randomID);
        event foundEvent = m.findEventInPerson(fetched, e.getCoords());
        //means it was able to find the correct event
        assertEquals(e.eventID, foundEvent.eventID);
        //okay now that we've fetched some fetching data, I'm under the assumption you want to test more about how my searchActtivity functions?
        //unfortunately, it works like everything else here, you just run the entire thing recursively to find what you want
        //but for convenience sake, I changed some of the code so we should be able to run it here.  if it stops working, that's 100% on you.
        SearchActivity r = new SearchActivity();
        r.m = model.getInstance();
        r.foundItems = new ArrayList<>();
        r.getAllMatching("Canada");
        boolean dumbEventFound = false;
        for(searchObject search : r.foundItems){
            if(search.objectType.equals("event")){
                event larry = (event) search.tag;
                if(larry.eventID.equals(e.eventID)){
                    dumbEventFound = true;
                }
            }
        }
        //so this is the filtered event that we found before, but through the search method used in searchActivity
        assertTrue(dumbEventFound);
    }


}