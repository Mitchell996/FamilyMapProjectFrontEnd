package com.example.mitchelljohnson.familymapproject.RequestsAndResponses.event;
import com.example.mitchelljohnson.familymapproject.RequestsAndResponses.event.event;

import java.util.ArrayList;
public class eventSet {

    public ArrayList<event> data;

    public eventSet(ArrayList<event> evs)
    {
        data = evs;
    }
}
